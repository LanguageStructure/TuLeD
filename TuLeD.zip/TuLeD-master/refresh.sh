#!/bin/bash

args=("$@")

python3 tuled/scripts/scripts/process_excel_sheet.py ${args[@]} data/languages.tsv data/concepts.tsv data/main.tsv
python3 tuled/scripts/scripts/initializedb.py tuled/development.ini data/main.tsv data/languages.tsv data/concepts.tsv data/sources.bib
