from pyramid.scripts import pserve

pserve.main(['pserve', '--reload', 'development.ini'])
